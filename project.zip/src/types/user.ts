export interface BaseUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  avatar?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Client extends BaseUser {
  type: 'client';
  savedProviders: string[];
  bookings: string[];
}

export interface ServiceProvider extends BaseUser {
  type: 'provider';
  company: string;
  services: string[];
  description: string;
  rating: number;
  reviews: Review[];
  availability: Availability[];
}

export interface Review {
  id: string;
  clientId: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

export interface Availability {
  id: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
}

export type User = Client | ServiceProvider;