import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { LocationBanner } from './components/location/LocationBanner';
import { Hero } from './components/home/Hero';
import { Services } from './components/home/Services';
import { GpsTrackingSection } from './components/home/GpsTrackingSection';
import { NearbyProviders } from './components/home/NearbyProviders';
import { ServicesPage } from './pages/ServicesPage';
import { ExpertsPage } from './pages/ExpertsPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { DocumentationPage } from './pages/DocumentationPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { SqlServerServices } from './components/services/SqlServerServices';
import { WindowsServerServices } from './components/services/WindowsServerServices';
import { Sage100Services } from './components/services/Sage100Services';
import { GpsTrackingServices } from './components/services/GpsTrackingServices';
import { BusinessConsultingServices } from './components/services/business/BusinessConsultingServices';
import { WebDevelopmentServices } from './components/services/web/WebDevelopmentServices';
import { DigitalMarketingServices } from './components/services/marketing/DigitalMarketingServices';
import { DiscoverServicesPage } from './pages/DiscoverServicesPage';
import { useThemeStore } from './store/themeStore';

function HomePage() {
  return (
    <>
      <Hero />
      <Services />
      <GpsTrackingSection />
      <NearbyProviders />
    </>
  );
}

function App() {
  const colors = useThemeStore((state) => state.colors);

  return (
    <Router>
      <div 
        className="min-h-screen bg-gray-50 flex flex-col"
        style={{
          '--color-primary-50': colors.primary[50],
          '--color-primary-100': colors.primary[100],
          '--color-primary-500': colors.primary[500],
          '--color-primary-600': colors.primary[600],
          '--color-primary-700': colors.primary[700],
          '--color-accent-50': colors.accent[50],
          '--color-accent-100': colors.accent[100],
          '--color-accent-500': colors.accent[500],
          '--color-accent-600': colors.accent[600],
          '--color-accent-700': colors.accent[700],
        } as React.CSSProperties}
      >
        <LocationBanner />
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/discover-services" element={<DiscoverServicesPage />} />
            <Route path="/services/sql-server" element={<SqlServerServices />} />
            <Route path="/services/windows-server" element={<WindowsServerServices />} />
            <Route path="/services/sage100" element={<Sage100Services />} />
            <Route path="/services/gps-tracking" element={<GpsTrackingServices />} />
            <Route path="/services/business" element={<BusinessConsultingServices />} />
            <Route path="/services/web" element={<WebDevelopmentServices />} />
            <Route path="/services/marketing" element={<DigitalMarketingServices />} />
            <Route path="/experts" element={<ExpertsPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/documentation" element={<DocumentationPage />} />
            <Route path="/admin" element={<AdminDashboard />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;