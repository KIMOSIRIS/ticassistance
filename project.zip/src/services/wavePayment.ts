import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import CryptoJS from 'crypto-js';

interface WaveConfig {
  apiKey: string;
  merchantId: string;
  apiEndpoint: string;
}

interface WavePaymentRequest {
  amount: number;
  currency: string;
  customerPhone: string;
  description: string;
}

interface WavePaymentResponse {
  status: string;
  paymentUrl?: string;
  transactionId?: string;
  error?: string;
}

export class WavePaymentService {
  private config: WaveConfig;

  constructor(config: WaveConfig) {
    this.config = config;
  }

  private generateSignature(data: string, timestamp: string): string {
    const signatureData = `${data}${timestamp}${this.config.apiKey}`;
    return CryptoJS.SHA256(signatureData).toString();
  }

  async initiatePayment(request: WavePaymentRequest): Promise<WavePaymentResponse> {
    try {
      const timestamp = new Date().toISOString();
      const transactionId = uuidv4();

      const payload = {
        merchant_id: this.config.merchantId,
        transaction_id: transactionId,
        amount: request.amount.toString(),
        currency: request.currency,
        customer_number: request.customerPhone,
        description: request.description,
        callback_url: `${window.location.origin}/payment/callback`,
        timestamp,
      };

      const signature = this.generateSignature(JSON.stringify(payload), timestamp);

      const response = await axios.post(
        `${this.config.apiEndpoint}/v1/checkout`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            'X-API-Key': this.config.apiKey,
            'X-Signature': signature,
            'X-Timestamp': timestamp,
          },
        }
      );

      return {
        status: 'success',
        paymentUrl: response.data.payment_url,
        transactionId,
      };
    } catch (error) {
      console.error('Wave payment initiation failed:', error);
      return {
        status: 'error',
        error: 'Le paiement Wave n\'a pas pu être initié. Veuillez réessayer.',
      };
    }
  }

  async verifyPayment(transactionId: string): Promise<WavePaymentResponse> {
    try {
      const timestamp = new Date().toISOString();
      const payload = {
        merchant_id: this.config.merchantId,
        transaction_id: transactionId,
      };

      const signature = this.generateSignature(JSON.stringify(payload), timestamp);

      const response = await axios.get(
        `${this.config.apiEndpoint}/v1/transaction/${transactionId}`,
        {
          headers: {
            'X-API-Key': this.config.apiKey,
            'X-Signature': signature,
            'X-Timestamp': timestamp,
          },
        }
      );

      return {
        status: response.data.status,
        transactionId,
      };
    } catch (error) {
      console.error('Wave payment verification failed:', error);
      return {
        status: 'error',
        error: 'La vérification du paiement Wave a échoué.',
      };
    }
  }
}