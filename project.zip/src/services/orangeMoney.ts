import axios from 'axios';
import CryptoJS from 'crypto-js';

interface PaymentConfig {
  merchantId: string;
  merchantKey: string;
  apiEndpoint: string;
}

interface PaymentRequest {
  amount: number;
  currency: string;
  orderId: string;
  customerPhone: string;
  description: string;
}

interface PaymentResponse {
  status: string;
  paymentUrl?: string;
  transactionId?: string;
  error?: string;
}

export class OrangeMoneyService {
  private config: PaymentConfig;

  constructor(config: PaymentConfig) {
    this.config = config;
  }

  private generateSignature(data: string): string {
    return CryptoJS.HmacSHA256(data, this.config.merchantKey).toString();
  }

  private formatAmount(amount: number): string {
    return amount.toFixed(2);
  }

  async initiatePayment(request: PaymentRequest): Promise<PaymentResponse> {
    try {
      const timestamp = new Date().toISOString();
      const payload = {
        merchant_id: this.config.merchantId,
        order_id: request.orderId,
        amount: this.formatAmount(request.amount),
        currency: request.currency,
        customer_msisdn: request.customerPhone,
        description: request.description,
        timestamp,
      };

      const signature = this.generateSignature(JSON.stringify(payload));

      const response = await axios.post(
        `${this.config.apiEndpoint}/payment/initiate`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            'X-Signature': signature,
          },
        }
      );

      return {
        status: 'success',
        paymentUrl: response.data.payment_url,
        transactionId: response.data.transaction_id,
      };
    } catch (error) {
      console.error('Orange Money payment initiation failed:', error);
      return {
        status: 'error',
        error: 'Le paiement n\'a pas pu être initié. Veuillez réessayer.',
      };
    }
  }

  async verifyPayment(transactionId: string): Promise<PaymentResponse> {
    try {
      const timestamp = new Date().toISOString();
      const payload = {
        merchant_id: this.config.merchantId,
        transaction_id: transactionId,
        timestamp,
      };

      const signature = this.generateSignature(JSON.stringify(payload));

      const response = await axios.post(
        `${this.config.apiEndpoint}/payment/verify`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
            'X-Signature': signature,
          },
        }
      );

      return {
        status: response.data.status,
        transactionId,
      };
    } catch (error) {
      console.error('Orange Money payment verification failed:', error);
      return {
        status: 'error',
        error: 'La vérification du paiement a échoué.',
      };
    }
  }
}