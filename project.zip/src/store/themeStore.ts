import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface ThemeColors {
  primary: {
    50: string;
    100: string;
    500: string;
    600: string;
    700: string;
  };
  accent: {
    50: string;
    100: string;
    500: string;
    600: string;
    700: string;
  };
}

interface ThemeStore {
  colors: ThemeColors;
  updateColors: (newColors: Partial<ThemeColors>) => void;
  resetColors: () => void;
}

const defaultColors: ThemeColors = {
  primary: {
    50: '#fff7ed',
    100: '#ffedd5',
    500: '#f97316',
    600: '#ea580c',
    700: '#c2410c',
  },
  accent: {
    50: '#f0fdf4',
    100: '#dcfce7',
    500: '#22c55e',
    600: '#16a34a',
    700: '#15803d',
  },
};

export const useThemeStore = create<ThemeStore>()(
  persist(
    (set) => ({
      colors: defaultColors,
      updateColors: (newColors) =>
        set((state) => ({
          colors: {
            ...state.colors,
            ...newColors,
          },
        })),
      resetColors: () => set({ colors: defaultColors }),
    }),
    {
      name: 'theme-storage',
    }
  )
);