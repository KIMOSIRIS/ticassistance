import React from 'react';
import { ServiceProvider as ServiceProviderType } from '../../types/user';
import { Star } from 'lucide-react';

interface ProviderDashboardProps {
  provider: ServiceProviderType;
}

export function ProviderDashboard({ provider }: ProviderDashboardProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-sm rounded-lg p-6 mb-8">
        <div className="flex items-center space-x-4">
          <img
            src={provider.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=128&h=128&q=80'}
            alt={`${provider.firstName} ${provider.lastName}`}
            className="w-16 h-16 rounded-full"
          />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {provider.company}
            </h2>
            <p className="text-gray-600">
              {provider.firstName} {provider.lastName}
            </p>
            <div className="flex items-center mt-2">
              <Star className="w-5 h-5 text-yellow-400 fill-current" />
              <span className="ml-1 text-gray-600">{provider.rating.toFixed(1)}</span>
            </div>
          </div>
        </div>

        <div className="mt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">À propos</h3>
          <p className="text-gray-600">{provider.description}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Services proposés
          </h3>
          <ul className="space-y-2">
            {provider.services.map((service) => (
              <li
                key={service}
                className="bg-gray-50 px-4 py-2 rounded-md text-gray-700"
              >
                {service}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Disponibilités
          </h3>
          <div className="space-y-4">
            {provider.availability.map((slot) => (
              <div
                key={slot.id}
                className="bg-gray-50 px-4 py-2 rounded-md text-gray-700"
              >
                {new Date(slot.startTime).toLocaleTimeString()} - 
                {new Date(slot.endTime).toLocaleTimeString()}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}