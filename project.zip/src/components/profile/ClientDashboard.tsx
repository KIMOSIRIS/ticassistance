import React from 'react';
import { Client } from '../../types/user';
import { ServiceProvider } from '../providers/ServiceProvider';

interface ClientDashboardProps {
  client: Client;
}

export function ClientDashboard({ client }: ClientDashboardProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white shadow-sm rounded-lg p-6 mb-8">
        <div className="flex items-center space-x-4">
          <img
            src={client.avatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=128&h=128&q=80'}
            alt={`${client.firstName} ${client.lastName}`}
            className="w-16 h-16 rounded-full"
          />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              {client.firstName} {client.lastName}
            </h2>
            <p className="text-gray-600">{client.email}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Prestataires enregistrés
          </h3>
          <div className="space-y-4">
            {/* Placeholder for saved providers list */}
            <p className="text-gray-600">Aucun prestataire enregistré</p>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Réservations récentes
          </h3>
          <div className="space-y-4">
            {/* Placeholder for recent bookings */}
            <p className="text-gray-600">Aucune réservation récente</p>
          </div>
        </div>
      </div>
    </div>
  );
}