import React, { useState } from 'react';
import { X, Search as SearchIcon, Loader } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface SearchResult {
  id: string;
  title: string;
  type: 'service' | 'provider';
  description: string;
}

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const navigate = useNavigate();

  const handleSearch = async (searchQuery: string) => {
    setQuery(searchQuery);
    if (searchQuery.length < 2) {
      setResults([]);
      return;
    }

    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setResults([
        {
          id: '1',
          title: 'Développement Web',
          type: 'service',
          description: 'Services de développement web professionnel',
        },
        {
          id: '2',
          title: 'Marie Dubois',
          type: 'provider',
          description: 'Expert en développement web',
        },
      ]);
      setLoading(false);
    }, 500);
  };

  const handleResultClick = (result: SearchResult) => {
    onClose();
    if (result.type === 'service') {
      navigate(`/services/${result.id}`);
    } else {
      navigate(`/experts/${result.id}`);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-start justify-center pt-20">
      <div className="bg-white w-full max-w-2xl rounded-lg shadow-xl">
        <div className="p-4 border-b flex items-center">
          <SearchIcon className="w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Rechercher un service ou un expert..."
            className="flex-1 ml-3 outline-none"
            autoFocus
          />
          <button
            onClick={onClose}
            className="ml-2 text-gray-400 hover:text-gray-600"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="max-h-96 overflow-y-auto p-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader className="w-6 h-6 text-primary-600 animate-spin" />
            </div>
          ) : results.length > 0 ? (
            <div className="space-y-4">
              {results.map((result) => (
                <button
                  key={result.id}
                  onClick={() => handleResultClick(result)}
                  className="w-full text-left p-4 rounded-lg hover:bg-gray-50"
                >
                  <h3 className="text-lg font-semibold text-gray-900">
                    {result.title}
                  </h3>
                  <p className="text-sm text-gray-600">{result.description}</p>
                  <span className="text-xs text-primary-600 mt-1 inline-block">
                    {result.type === 'service' ? 'Service' : 'Expert'}
                  </span>
                </button>
              ))}
            </div>
          ) : query.length > 0 ? (
            <p className="text-center text-gray-500 py-8">
              Aucun résultat trouvé pour "{query}"
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}