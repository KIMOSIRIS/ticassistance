import React from 'react';
import { BarChart2, TrendingUp, Users, DollarSign } from 'lucide-react';

const stats = [
  {
    name: 'Utilisateurs Actifs',
    value: '2,345',
    change: '+12.3%',
    icon: Users,
  },
  {
    name: 'Services Vendus',
    value: '456',
    change: '+23.5%',
    icon: BarChart2,
  },
  {
    name: 'Revenus Mensuels',
    value: '15,678,900 FCFA',
    change: '+18.2%',
    icon: DollarSign,
  },
  {
    name: 'Taux de Conversion',
    value: '3.2%',
    change: '+5.4%',
    icon: TrendingUp,
  },
];

export function Analytics() {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold mb-6">Tableau de Bord Analytique</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.name} className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">{stat.name}</p>
                <p className="text-2xl font-semibold mt-1">{stat.value}</p>
              </div>
              <div className="bg-primary-100 p-3 rounded-lg">
                <stat.icon className="w-6 h-6 text-primary-600" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-green-600 text-sm font-medium">
                {stat.change}
              </span>
              <span className="text-gray-500 text-sm ml-2">vs mois dernier</span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-medium mb-4">Services les Plus Populaires</h3>
          <div className="space-y-4">
            {[
              { name: 'Administration Windows Server', value: '32%' },
              { name: 'Développement Web', value: '28%' },
              { name: 'Support Technique', value: '20%' },
            ].map((service) => (
              <div key={service.name} className="flex items-center justify-between">
                <span className="text-gray-600">{service.name}</span>
                <span className="font-medium">{service.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-medium mb-4">Répartition des Clients</h3>
          <div className="space-y-4">
            {[
              { name: 'Entreprises', value: '45%' },
              { name: 'Particuliers', value: '35%' },
              { name: 'Institutions', value: '20%' },
            ].map((category) => (
              <div key={category.name} className="flex items-center justify-between">
                <span className="text-gray-600">{category.name}</span>
                <span className="font-medium">{category.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}