import React from 'react';
import { Settings, RotateCcw } from 'lucide-react';
import { useThemeStore } from '../../store/themeStore';

export function ThemeManager() {
  const { colors, updateColors, resetColors } = useThemeStore();

  const handleColorChange = (
    type: 'primary' | 'accent',
    shade: '50' | '100' | '500' | '600' | '700',
    value: string
  ) => {
    updateColors({
      [type]: {
        ...colors[type],
        [shade]: value,
      },
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Settings className="w-6 h-6 text-primary-600 mr-2" />
          <h2 className="text-xl font-semibold">Gestion des Thèmes</h2>
        </div>
        <button
          onClick={resetColors}
          className="flex items-center text-gray-600 hover:text-primary-600"
        >
          <RotateCcw className="w-4 h-4 mr-1" />
          Réinitialiser
        </button>
      </div>

      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium mb-4">Couleurs Primaires</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {Object.entries(colors.primary).map(([shade, value]) => (
              <div key={shade}>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {shade}
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="color"
                    value={value}
                    onChange={(e) =>
                      handleColorChange(
                        'primary',
                        shade as '50' | '100' | '500' | '600' | '700',
                        e.target.value
                      )
                    }
                    className="w-8 h-8 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={value}
                    onChange={(e) =>
                      handleColorChange(
                        'primary',
                        shade as '50' | '100' | '500' | '600' | '700',
                        e.target.value
                      )
                    }
                    className="flex-1 px-2 py-1 text-sm border rounded"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium mb-4">Couleurs d'Accent</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {Object.entries(colors.accent).map(([shade, value]) => (
              <div key={shade}>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  {shade}
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="color"
                    value={value}
                    onChange={(e) =>
                      handleColorChange(
                        'accent',
                        shade as '50' | '100' | '500' | '600' | '700',
                        e.target.value
                      )
                    }
                    className="w-8 h-8 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={value}
                    onChange={(e) =>
                      handleColorChange(
                        'accent',
                        shade as '50' | '100' | '500' | '600' | '700',
                        e.target.value
                      )
                    }
                    className="flex-1 px-2 py-1 text-sm border rounded"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="text-lg font-medium mb-4">Aperçu</h3>
          <div className="space-y-4">
            <div className="flex space-x-4">
              {Object.values(colors.primary).map((color, index) => (
                <div
                  key={index}
                  className="w-12 h-12 rounded"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            <div className="flex space-x-4">
              {Object.values(colors.accent).map((color, index) => (
                <div
                  key={index}
                  className="w-12 h-12 rounded"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}