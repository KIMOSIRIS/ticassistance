import React from 'react';
import { Settings, Clock, Bell, Map } from 'lucide-react';

const settings = [
  {
    icon: <Clock className="w-5 h-5" />,
    name: 'Intervalle de mise à jour',
    value: '30 secondes',
    description: 'Fréquence de rafraîchissement des positions'
  },
  {
    icon: <Bell className="w-5 h-5" />,
    name: 'Seuil d\'alerte batterie',
    value: '20%',
    description: 'Niveau de batterie déclenchant une alerte'
  },
  {
    icon: <Map className="w-5 h-5" />,
    name: 'Zoom par défaut',
    value: '13',
    description: 'Niveau de zoom initial de la carte'
  }
];

export function TrackingSettings() {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <Settings className="w-6 h-6 text-primary-600 mr-2" />
        <h2 className="text-xl font-semibold">Paramètres de Suivi</h2>
      </div>

      <div className="space-y-6">
        {settings.map((setting, index) => (
          <div key={index} className="flex items-start">
            <div className="flex-shrink-0 mt-1">
              <div className="w-8 h-8 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600">
                {setting.icon}
              </div>
            </div>
            <div className="ml-4 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-medium text-gray-900">{setting.name}</h3>
                <span className="text-sm text-primary-600 font-medium">{setting.value}</span>
              </div>
              <p className="text-sm text-gray-500 mt-1">{setting.description}</p>
              <input
                type="range"
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-2"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}