import React, { useState } from 'react';
import { Settings, Plus, Edit2, Trash2, Toggle } from 'lucide-react';

interface TrackingFeature {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  type: 'basic' | 'premium';
}

const defaultFeatures: TrackingFeature[] = [
  {
    id: '1',
    name: 'Suivi en temps réel',
    description: 'Localisation GPS en direct des véhicules',
    enabled: true,
    type: 'basic'
  },
  {
    id: '2',
    name: 'Historique des trajets',
    description: 'Consultation de l\'historique des déplacements',
    enabled: true,
    type: 'basic'
  },
  {
    id: '3',
    name: 'Alertes batterie',
    description: 'Notifications de niveau de batterie faible',
    enabled: true,
    type: 'premium'
  },
  {
    id: '4',
    name: 'Zones de géofencing',
    description: 'Définition de zones autorisées/interdites',
    enabled: false,
    type: 'premium'
  }
];

export function TrackingFeatures() {
  const [features, setFeatures] = useState<TrackingFeature[]>(defaultFeatures);
  const [editingFeature, setEditingFeature] = useState<TrackingFeature | null>(null);

  const toggleFeature = (id: string) => {
    setFeatures(features.map(feature =>
      feature.id === id ? { ...feature, enabled: !feature.enabled } : feature
    ));
  };

  const deleteFeature = (id: string) => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer cette fonctionnalité ?')) {
      setFeatures(features.filter(feature => feature.id !== id));
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Settings className="w-6 h-6 text-primary-600 mr-2" />
          <h2 className="text-xl font-semibold">Gestion des Fonctionnalités</h2>
        </div>
        <button className="flex items-center px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">
          <Plus className="w-5 h-5 mr-2" />
          Ajouter
        </button>
      </div>

      <div className="space-y-4">
        {features.map((feature) => (
          <div
            key={feature.id}
            className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
          >
            <div className="flex-1">
              <div className="flex items-center">
                <h3 className="font-medium text-gray-900">{feature.name}</h3>
                <span className={`ml-2 px-2 py-1 text-xs rounded-full ${
                  feature.type === 'premium' ? 'bg-primary-100 text-primary-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {feature.type === 'premium' ? 'Premium' : 'Basic'}
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">{feature.description}</p>
            </div>

            <div className="flex items-center space-x-4 ml-4">
              <button
                onClick={() => toggleFeature(feature.id)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  feature.enabled ? 'bg-green-500' : 'bg-gray-300'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    feature.enabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
              
              <button
                onClick={() => setEditingFeature(feature)}
                className="text-gray-600 hover:text-primary-600"
              >
                <Edit2 className="w-5 h-5" />
              </button>
              
              <button
                onClick={() => deleteFeature(feature.id)}
                className="text-gray-600 hover:text-red-600"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}