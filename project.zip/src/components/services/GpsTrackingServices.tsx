import React from 'react';
import { GpsFeatures } from './gps/GpsFeatures';
import { GpsPricing } from './gps/GpsPricing';
import { GpsDemo } from './gps/GpsDemo';

export function GpsTrackingServices() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Solution de Géolocalisation GPS
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Une plateforme complète pour optimiser la gestion de votre flotte
            et réduire vos coûts opérationnels
          </p>
        </div>

        <div className="space-y-16">
          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-8">
              Fonctionnalités Principales
            </h2>
            <GpsFeatures />
          </section>

          <section>
            <h2 className="text-2xl font-bold text-gray-900 mb-8">
              Nos Forfaits
            </h2>
            <GpsPricing />
          </section>

          <section>
            <GpsDemo />
          </section>
        </div>
      </div>
    </div>
  );
}