import { Briefcase, Code, MessageSquare, Database, Server, Calculator } from 'lucide-react';

export const mainServices = [
  {
    title: 'Administration Windows Server',
    description: 'Services complets d\'administration et gestion Windows Server',
    icon: Server,
    path: '/services/windows-server'
  },
  {
    title: 'Administration SQL Server',
    description: 'Services complets d\'administration, optimisation et maintenance SQL Server',
    icon: Database,
    path: '/services/sql-server'
  },
  {
    title: 'Administration SAGE 100',
    description: 'Services complets d\'administration et support SAGE 100 pour entreprises',
    icon: Calculator,
    path: '/services/sage100'
  },
  {
    title: 'Conseil Business',
    description: 'Expertise stratégique pour développer votre entreprise',
    icon: Briefcase,
    path: '/services/business'
  },
  {
    title: 'Développement Web',
    description: 'Solutions digitales sur mesure pour votre présence en ligne',
    icon: Code,
    path: '/services/web'
  },
  {
    title: 'Marketing Digital',
    description: 'Stratégies marketing pour augmenter votre visibilité',
    icon: MessageSquare,
    path: '/services/marketing'
  }
];