import React from 'react';
import { Server, Shield, Settings, Network, Monitor, Database, Cloud, Users } from 'lucide-react';

interface WindowsServiceCard {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
  price: number;
}

const windowsServices: WindowsServiceCard[] = [
  {
    icon: <Server className="w-6 h-6" />,
    title: "Installation et Configuration",
    description: "Installation complète de Windows Server, configuration des rôles et services, optimisation des performances",
    features: [
      "Installation de Windows Server 2019/2022",
      "Configuration des rôles et fonctionnalités",
      "Optimisation des performances système",
      "Migration depuis versions antérieures"
    ],
    price: 300000
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Sécurité et Active Directory",
    description: "Configuration d'Active Directory, gestion des politiques de sécurité, audit et conformité",
    features: [
      "Configuration d'Active Directory",
      "Gestion des GPO",
      "Audit de sécurité complet",
      "Mise en place de WSUS"
    ],
    price: 250000
  },
  {
    icon: <Settings className="w-6 h-6" />,
    title: "Maintenance et Support",
    description: "Maintenance préventive, mises à jour, surveillance système 24/7, support technique",
    features: [
      "Maintenance préventive mensuelle",
      "Gestion des mises à jour",
      "Monitoring 24/7",
      "Support technique prioritaire"
    ],
    price: 200000
  },
  {
    icon: <Network className="w-6 h-6" />,
    title: "Services Réseau",
    description: "Configuration DNS, DHCP, VPN, services de fichiers et d'impression",
    features: [
      "Configuration DNS et DHCP",
      "Mise en place VPN",
      "Services de fichiers",
      "Gestion des imprimantes réseau"
    ],
    price: 180000
  },
  {
    icon: <Cloud className="w-6 h-6" />,
    title: "Solutions Cloud Hybrides",
    description: "Intégration avec Azure, sauvegarde cloud, solutions hybrides",
    features: [
      "Intégration Azure AD",
      "Sauvegarde cloud",
      "Configuration Azure Site Recovery",
      "Solutions de stockage hybride"
    ],
    price: 350000
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: "Formation et Documentation",
    description: "Formation des administrateurs, documentation technique, transfert de compétences",
    features: [
      "Formation administrateurs",
      "Documentation technique",
      "Procédures d'exploitation",
      "Support post-formation"
    ],
    price: 150000
  }
];

export function WindowsServerServices() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Services Windows Server</h2>
          <p className="mt-4 text-xl text-gray-600">
            Solutions professionnelles d'administration et de gestion Windows Server
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {windowsServices.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {service.title}
              </h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <ul className="mb-6 space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                    <span className="w-1.5 h-1.5 bg-primary-600 rounded-full mr-2"></span>
                    {feature}
                  </li>
                ))}
              </ul>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-primary-600">
                  {new Intl.NumberFormat('fr-FR', {
                    style: 'currency',
                    currency: 'XOF'
                  }).format(service.price)}
                </span>
                <button className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors">
                  Commander
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white rounded-lg shadow-md p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Pourquoi choisir nos services Windows Server ?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="flex items-start">
              <Shield className="w-8 h-8 text-primary-600 mr-4" />
              <div>
                <h4 className="text-lg font-semibold mb-2">Expertise Certifiée</h4>
                <p className="text-gray-600">Nos experts sont certifiés Microsoft et possèdent une vaste expérience</p>
              </div>
            </div>
            <div className="flex items-start">
              <Monitor className="w-8 h-8 text-primary-600 mr-4" />
              <div>
                <h4 className="text-lg font-semibold mb-2">Support 24/7</h4>
                <p className="text-gray-600">Une équipe dédiée disponible 24h/24 et 7j/7 pour vous assister</p>
              </div>
            </div>
            <div className="flex items-start">
              <Database className="w-8 h-8 text-primary-600 mr-4" />
              <div>
                <h4 className="text-lg font-semibold mb-2">Solutions Sur Mesure</h4>
                <p className="text-gray-600">Des solutions adaptées à vos besoins spécifiques</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}