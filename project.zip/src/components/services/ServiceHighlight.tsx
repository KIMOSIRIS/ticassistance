import React from 'react';
import { CheckCircle } from 'lucide-react';

const highlights = [
  {
    title: 'Expertise Technique',
    description: 'Une équipe d\'experts certifiés avec des années d\'expérience',
    features: [
      'Professionnels certifiés',
      'Formation continue',
      'Veille technologique',
    ],
  },
  {
    title: 'Support Premium',
    description: 'Un accompagnement personnalisé et réactif',
    features: [
      'Support 24/7',
      'Temps de réponse garanti',
      'Suivi personnalisé',
    ],
  },
  {
    title: 'Solutions Sur Mesure',
    description: 'Des services adaptés à vos besoins spécifiques',
    features: [
      'Analyse des besoins',
      'Solutions personnalisées',
      'Évolutivité garantie',
    ],
  },
];

export function ServiceHighlight() {
  return (
    <div className="bg-white rounded-lg shadow-md p-8 mb-16">
      <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
        Pourquoi Choisir Nos Services ?
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {highlights.map((highlight, index) => (
          <div key={index} className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900">
              {highlight.title}
            </h3>
            <p className="text-gray-600">{highlight.description}</p>
            <ul className="space-y-2">
              {highlight.features.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}