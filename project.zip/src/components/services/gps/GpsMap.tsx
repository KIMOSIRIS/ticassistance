import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Compass, Navigation } from 'lucide-react';

// Fix for default marker icons in React
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Vehicle {
  id: string;
  position: [number, number];
  heading: number;
  speed: number;
  lastUpdate: Date;
}

const createVehicleIcon = (heading: number) => {
  return L.divIcon({
    className: 'custom-vehicle-marker',
    html: `
      <div class="vehicle-marker">
        <div class="vehicle-icon" style="transform: rotate(${heading}deg)">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
            <path d="M12 2L19 21H5L12 2Z" />
          </svg>
        </div>
      </div>
    `,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
};

const initialVehicles: Vehicle[] = [
  { 
    id: 'VH001',
    position: [5.3596, -4.0083], // Abidjan coordinates
    heading: 45,
    speed: 50,
    lastUpdate: new Date()
  },
  {
    id: 'VH002',
    position: [5.3499, -4.0147],
    heading: 180,
    speed: 35,
    lastUpdate: new Date()
  },
  {
    id: 'VH003',
    position: [5.3698, -3.9967],
    heading: 270,
    speed: 42,
    lastUpdate: new Date()
  }
];

export function GpsMap() {
  const [vehicles, setVehicles] = useState<Vehicle[]>(initialVehicles);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setVehicles(prevVehicles =>
        prevVehicles.map(vehicle => ({
          ...vehicle,
          position: [
            vehicle.position[0] + (Math.random() - 0.5) * 0.001,
            vehicle.position[1] + (Math.random() - 0.5) * 0.001,
          ],
          heading: (vehicle.heading + Math.random() * 10 - 5) % 360,
          speed: Math.max(0, Math.min(120, vehicle.speed + (Math.random() - 0.5) * 5)),
          lastUpdate: new Date()
        }))
      );
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative h-[500px] rounded-lg overflow-hidden">
      <style jsx global>{`
        .vehicle-marker {
          width: 24px;
          height: 24px;
          color: #16a34a;
        }
        .vehicle-icon {
          transition: transform 0.3s ease-in-out;
        }
      `}</style>

      <MapContainer
        center={[5.3596, -4.0083]} // Centered on Abidjan
        zoom={13}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        {vehicles.map(vehicle => (
          <Marker
            key={vehicle.id}
            position={vehicle.position}
            icon={createVehicleIcon(vehicle.heading)}
            eventHandlers={{
              click: () => setSelectedVehicle(vehicle)
            }}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-semibold">{vehicle.id}</h3>
                <p>Vitesse: {Math.round(vehicle.speed)} km/h</p>
                <p>Direction: {Math.round(vehicle.heading)}°</p>
                <p>Dernière mise à jour: {vehicle.lastUpdate.toLocaleTimeString()}</p>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      <div className="absolute top-4 right-4 z-[1000] bg-white rounded-lg shadow-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Compass className="w-5 h-5 text-primary-600" />
          <span className="font-semibold">Véhicules actifs</span>
        </div>
        <div className="space-y-2">
          {vehicles.map(vehicle => (
            <div
              key={vehicle.id}
              className={`flex items-center gap-2 p-2 rounded cursor-pointer transition-colors ${
                selectedVehicle?.id === vehicle.id
                  ? 'bg-primary-100'
                  : 'hover:bg-gray-100'
              }`}
              onClick={() => setSelectedVehicle(vehicle)}
            >
              <Navigation className="w-4 h-4 text-accent-600" />
              <div>
                <div className="font-medium">{vehicle.id}</div>
                <div className="text-sm text-gray-600">
                  {Math.round(vehicle.speed)} km/h
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}