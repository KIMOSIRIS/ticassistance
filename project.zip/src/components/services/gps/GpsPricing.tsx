import React from 'react';
import { Check } from 'lucide-react';

const pricingPlans = [
  {
    name: "Essentiel",
    price: 25000,
    description: "Pour les petites flottes",
    features: [
      "Suivi GPS en temps réel",
      "Historique des trajets 30 jours",
      "Rapports basiques",
      "Support email"
    ]
  },
  {
    name: "Business",
    price: 45000,
    description: "Pour les flottes moyennes",
    features: [
      "Tout de l'offre Essentiel",
      "Optimisation d'itinéraires",
      "Historique illimité",
      "Alertes personnalisées",
      "Support prioritaire"
    ]
  },
  {
    name: "Enterprise",
    price: "Sur mesure",
    description: "Pour les grandes flottes",
    features: [
      "Tout de l'offre Business",
      "API personnalisée",
      "Intégration sur mesure",
      "Support dédié 24/7",
      "Formation sur site",
      "SLA garanti"
    ]
  }
];

export function GpsPricing() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {pricingPlans.map((plan, index) => (
        <div
          key={index}
          className="bg-white rounded-lg shadow-md p-6 flex flex-col"
        >
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            {plan.name}
          </h3>
          <p className="text-gray-600 mb-4">{plan.description}</p>
          <div className="mb-6">
            <span className="text-4xl font-bold text-primary-600">
              {typeof plan.price === 'number' 
                ? new Intl.NumberFormat('fr-FR', {
                    style: 'currency',
                    currency: 'XOF',
                    maximumFractionDigits: 0
                  }).format(plan.price)
                : plan.price}
            </span>
            {typeof plan.price === 'number' && <span className="text-gray-600">/mois</span>}
          </div>
          <ul className="space-y-3 mb-8 flex-grow">
            {plan.features.map((feature, featureIndex) => (
              <li key={featureIndex} className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500" />
                <span className="text-gray-700">{feature}</span>
              </li>
            ))}
          </ul>
          <button className="w-full bg-primary-600 text-white py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors">
            Sélectionner
          </button>
        </div>
      ))}
    </div>
  );
}