import React, { useState } from 'react';
import { Navigation, Map, Compass } from 'lucide-react';
import { GpsMap } from './GpsMap';

export function GpsDemo() {
  const [showDemo, setShowDemo] = useState(false);

  return (
    <div className="bg-primary-600 rounded-2xl p-8 text-white">
      <div className="max-w-3xl mx-auto">
        {!showDemo ? (
          <>
            <Navigation className="w-12 h-12 mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-4">
              Essayez notre plateforme de démonstration
            </h3>
            <p className="text-primary-100 mb-8">
              Découvrez en direct les fonctionnalités de notre solution de géolocalisation
              avec notre démo interactive.
            </p>
            <button
              onClick={() => setShowDemo(true)}
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-primary-600 bg-white hover:bg-primary-50 transition-colors duration-300"
            >
              <Map className="w-5 h-5 mr-2" />
              Lancer la démo
            </button>
          </>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-2xl font-bold">Démo GPS Tracking</h3>
              <button
                onClick={() => setShowDemo(false)}
                className="text-white hover:text-primary-100 transition-colors"
              >
                Fermer la démo
              </button>
            </div>
            <GpsMap />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-primary-700 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span>Vitesse moyenne</span>
                  <span className="font-bold">45 km/h</span>
                </div>
              </div>
              <div className="bg-primary-700 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span>Distance parcourue</span>
                  <span className="font-bold">127.5 km</span>
                </div>
              </div>
              <div className="bg-primary-700 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span>Temps de trajet</span>
                  <span className="font-bold">2h 45min</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}