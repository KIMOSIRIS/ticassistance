import React from 'react';
import { MapPin, Route, Clock, Shield, BarChart } from 'lucide-react';

export const gpsFeatures = [
  {
    icon: <MapPin className="w-6 h-6" />,
    title: "Suivi en Temps Réel",
    description: "Localisez vos véhicules avec précision en temps réel"
  },
  {
    icon: <Route className="w-6 h-6" />,
    title: "Optimisation d'Itinéraires",
    description: "Réduisez vos coûts avec des trajets optimisés"
  },
  {
    icon: <Clock className="w-6 h-6" />,
    title: "Historique Détaillé",
    description: "Accédez à l'historique complet des déplacements"
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Sécurité Avancée",
    description: "Protection et surveillance 24/7 de votre flotte"
  },
  {
    icon: <BarChart className="w-6 h-6" />,
    title: "Analyses & Rapports",
    description: "Statistiques détaillées et rapports personnalisés"
  }
];

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300">
      <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

export function GpsFeatures() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {gpsFeatures.map((feature, index) => (
        <FeatureCard key={index} {...feature} />
      ))}
    </div>
  );
}