import React from 'react';
import { Server, Database, Calculator, Navigation, Code, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';

const categories = [
  {
    icon: <Server className="w-8 h-8" />,
    title: 'Windows Server',
    description: 'Administration et gestion complète de vos serveurs Windows',
    path: '/services/windows-server',
    color: 'bg-blue-500',
  },
  {
    icon: <Database className="w-8 h-8" />,
    title: 'SQL Server',
    description: 'Optimisation et maintenance de vos bases de données',
    path: '/services/sql-server',
    color: 'bg-purple-500',
  },
  {
    icon: <Calculator className="w-8 h-8" />,
    title: 'SAGE 100',
    description: 'Gestion et support de votre solution SAGE',
    path: '/services/sage100',
    color: 'bg-green-500',
  },
  {
    icon: <Navigation className="w-8 h-8" />,
    title: 'GPS Tracking',
    description: 'Solutions de géolocalisation et suivi en temps réel',
    path: '/services/gps-tracking',
    color: 'bg-red-500',
  },
  {
    icon: <Code className="w-8 h-8" />,
    title: 'Développement Web',
    description: 'Création de solutions web sur mesure',
    path: '/services/web',
    color: 'bg-indigo-500',
  },
  {
    icon: <MessageSquare className="w-8 h-8" />,
    title: 'Marketing Digital',
    description: 'Stratégies marketing pour votre croissance',
    path: '/services/marketing',
    color: 'bg-yellow-500',
  },
];

export function ServiceCategory() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
      {categories.map((category, index) => (
        <Link
          key={index}
          to={category.path}
          className="group bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300"
        >
          <div className={`w-16 h-16 ${category.color} rounded-lg flex items-center justify-center text-white mb-4 group-hover:scale-110 transition-transform`}>
            {category.icon}
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            {category.title}
          </h3>
          <p className="text-gray-600">{category.description}</p>
        </Link>
      ))}
    </div>
  );
}