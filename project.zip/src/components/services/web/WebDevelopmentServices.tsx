import React from 'react';
import { WebFeatures } from './WebFeatures';
import { WebTechnologies } from './WebTechnologies';
import { WebProcess } from './WebProcess';
import { WebPricing } from './WebPricing';
import { WebPortfolio } from './WebPortfolio';
import { WebTestimonials } from './WebTestimonials';

export function WebDevelopmentServices() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Développement Web
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Des solutions web innovantes et sur mesure pour dynamiser votre présence en ligne
            et accélérer votre croissance digitale
          </p>
        </div>

        <div className="space-y-16">
          <WebFeatures />
          <WebTechnologies />
          <WebProcess />
          <WebPortfolio />
          <WebPricing />
          <WebTestimonials />
        </div>
      </div>
    </div>
  );
}