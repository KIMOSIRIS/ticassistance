import React from 'react';

const technologies = [
  {
    category: "Front-end",
    items: ["React", "Vue.js", "Angular", "Next.js", "Tailwind CSS", "TypeScript"]
  },
  {
    category: "Back-end",
    items: ["Node.js", "Python", "PHP", "Java", "Ruby on Rails", ".NET"]
  },
  {
    category: "Base de données",
    items: ["MySQL", "PostgreSQL", "MongoDB", "Redis", "Firebase"]
  },
  {
    category: "Mobile",
    items: ["React Native", "Flutter", "iOS Swift", "Android Kotlin"]
  }
];

export function WebTechnologies() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Technologies</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {technologies.map((tech, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              {tech.category}
            </h3>
            <ul className="space-y-2">
              {tech.items.map((item, itemIndex) => (
                <li
                  key={itemIndex}
                  className="text-gray-600 flex items-center space-x-2"
                >
                  <span className="w-1.5 h-1.5 bg-primary-600 rounded-full"></span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}