import React from 'react';
import { Globe, ShoppingCart, Code, Smartphone, Search, Shield } from 'lucide-react';

const features = [
  {
    icon: <Globe className="w-6 h-6" />,
    title: "Sites Vitrines",
    description: "Sites web professionnels et responsive pour présenter votre entreprise"
  },
  {
    icon: <ShoppingCart className="w-6 h-6" />,
    title: "E-commerce",
    description: "Solutions de vente en ligne complètes et personnalisées"
  },
  {
    icon: <Code className="w-6 h-6" />,
    title: "Applications Web",
    description: "Applications web sur mesure pour optimiser vos processus"
  },
  {
    icon: <Smartphone className="w-6 h-6" />,
    title: "Applications Mobiles",
    description: "Applications mobiles natives et cross-platform"
  },
  {
    icon: <Search className="w-6 h-6" />,
    title: "SEO",
    description: "Optimisation pour les moteurs de recherche"
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Sécurité Web",
    description: "Protection et sécurisation de vos applications"
  }
];

export function WebFeatures() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Nos Services Web</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300"
          >
            <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
              {feature.icon}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {feature.title}
            </h3>
            <p className="text-gray-600">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}