import React from 'react';

const projects = [
  {
    title: "E-commerce Mode",
    description: "Plateforme de vente en ligne pour une marque de mode",
    image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Node.js", "MongoDB"]
  },
  {
    title: "Application Immobilière",
    description: "Application web de gestion immobilière",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800&q=80",
    tags: ["Vue.js", "Laravel", "PostgreSQL"]
  },
  {
    title: "Plateforme E-learning",
    description: "Solution d'apprentissage en ligne",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80",
    tags: ["Next.js", "Python", "AWS"]
  }
];

export function WebPortfolio() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Nos Réalisations</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={project.image}
              alt={project.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {project.title}
              </h3>
              <p className="text-gray-600 mb-4">{project.description}</p>
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag, tagIndex) => (
                  <span
                    key={tagIndex}
                    className="px-3 py-1 bg-primary-100 text-primary-600 rounded-full text-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}