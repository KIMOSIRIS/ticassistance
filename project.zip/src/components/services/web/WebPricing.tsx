import React from 'react';
import { Check } from 'lucide-react';

const plans = [
  {
    name: "Site Vitrine",
    price: 750000,
    description: "Pour les petites entreprises",
    features: [
      "Design responsive",
      "5 pages personnalisées",
      "Formulaire de contact",
      "Optimisation SEO",
      "Hébergement 1 an"
    ]
  },
  {
    name: "E-commerce",
    price: 2500000,
    description: "Pour les boutiques en ligne",
    features: [
      "Tout du plan Site Vitrine",
      "Catalogue produits",
      "Système de paiement",
      "Gestion des stocks",
      "Panel d'administration",
      "Formation utilisateur"
    ]
  },
  {
    name: "Sur Mesure",
    price: "Sur devis",
    description: "Pour les projets complexes",
    features: [
      "Application personnalisée",
      "Architecture sur mesure",
      "API dédiée",
      "Tests automatisés",
      "Support premium",
      "Maintenance évolutive"
    ]
  }
];

export function WebPricing() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Nos Forfaits</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 flex flex-col"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {plan.name}
            </h3>
            <p className="text-gray-600 mb-4">{plan.description}</p>
            <div className="mb-6">
              <span className="text-4xl font-bold text-primary-600">
                {typeof plan.price === 'number' 
                  ? new Intl.NumberFormat('fr-FR', {
                      style: 'currency',
                      currency: 'XOF',
                      maximumFractionDigits: 0
                    }).format(plan.price)
                  : plan.price}
              </span>
            </div>
            <ul className="space-y-3 mb-8 flex-grow">
              {plan.features.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
            <button className="w-full bg-primary-600 text-white py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors">
              Commencer
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}