import React from 'react';
import { Building2, ShoppingBag, Factory, Truck, Building, Hotel } from 'lucide-react';

const industries = [
  {
    icon: <Building2 className="w-6 h-6" />,
    title: "Services Financiers",
    description: "Banques, assurances et services financiers"
  },
  {
    icon: <ShoppingBag className="w-6 h-6" />,
    title: "Commerce de Détail",
    description: "Distribution et commerce de détail"
  },
  {
    icon: <Factory className="w-6 h-6" />,
    title: "Industrie",
    description: "Production et manufacture"
  },
  {
    icon: <Truck className="w-6 h-6" />,
    title: "Transport & Logistique",
    description: "Transport et chaîne d'approvisionnement"
  },
  {
    icon: <Building className="w-6 h-6" />,
    title: "Immobilier",
    description: "Immobilier commercial et résidentiel"
  },
  {
    icon: <Hotel className="w-6 h-6" />,
    title: "Hôtellerie",
    description: "Hôtellerie et restauration"
  }
];

export function BusinessIndustries() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Secteurs d'Activité</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {industries.map((industry, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300"
          >
            <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
              {industry.icon}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {industry.title}
            </h3>
            <p className="text-gray-600">{industry.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}