import React from 'react';
import { TrendingUp, Target, BarChart2, Users2, Briefcase, LineChart } from 'lucide-react';

const features = [
  {
    icon: <TrendingUp className="w-6 h-6" />,
    title: "Stratégie de Croissance",
    description: "Développez votre entreprise avec des stratégies de croissance personnalisées"
  },
  {
    icon: <Target className="w-6 h-6" />,
    title: "Optimisation Opérationnelle",
    description: "Améliorez l'efficacité de vos processus métier"
  },
  {
    icon: <BarChart2 className="w-6 h-6" />,
    title: "Analyse Financière",
    description: "Optimisez vos performances financières et votre rentabilité"
  },
  {
    icon: <Users2 className="w-6 h-6" />,
    title: "Gestion du Changement",
    description: "Accompagnement dans la transformation de votre organisation"
  },
  {
    icon: <Briefcase className="w-6 h-6" />,
    title: "Développement Commercial",
    description: "Stratégies de vente et développement de marchés"
  },
  {
    icon: <LineChart className="w-6 h-6" />,
    title: "Performance Management",
    description: "Systèmes de suivi et d'amélioration des performances"
  }
];

export function BusinessFeatures() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Nos Services de Conseil</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300"
          >
            <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
              {feature.icon}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {feature.title}
            </h3>
            <p className="text-gray-600">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}