import React from 'react';
import { BusinessFeatures } from './BusinessFeatures';
import { BusinessPricing } from './BusinessPricing';
import { BusinessProcess } from './BusinessProcess';
import { BusinessIndustries } from './BusinessIndustries';
import { BusinessTestimonials } from './BusinessTestimonials';

export function BusinessConsultingServices() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Conseil Business
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Des solutions stratégiques pour accélérer la croissance de votre entreprise
            et optimiser vos performances
          </p>
        </div>

        <div className="space-y-16">
          <BusinessFeatures />
          <BusinessProcess />
          <BusinessIndustries />
          <BusinessPricing />
          <BusinessTestimonials />
        </div>
      </div>
    </div>
  );
}