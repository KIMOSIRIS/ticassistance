import React from 'react';
import { Star } from 'lucide-react';

const testimonials = [
  {
    content: "L'expertise de TICASSISTANCE a été déterminante dans notre transformation digitale. Leur approche stratégique nous a permis d'atteindre nos objectifs plus rapidement.",
    author: "Sophie Martin",
    position: "CEO, TechCorp",
    rating: 5,
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  },
  {
    content: "Un accompagnement professionnel et des résultats concrets. Nous avons vu une amélioration significative de nos performances après leur intervention.",
    author: "Jean Dubois",
    position: "Directeur Commercial, InnovGroup",
    rating: 5,
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  },
  {
    content: "Leur expertise en stratégie d'entreprise nous a permis de redéfinir notre positionnement et d'accélérer notre croissance.",
    author: "Marie Lambert",
    position: "DG, StartupPlus",
    rating: 5,
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
  }
];

export function BusinessTestimonials() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Témoignages Clients</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {testimonials.map((testimonial, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center space-x-1 mb-4">
              {[...Array(testimonial.rating)].map((_, i) => (
                <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
              ))}
            </div>
            <p className="text-gray-600 mb-4">{testimonial.content}</p>
            <div className="flex items-center">
              <img
                src={testimonial.image}
                alt={testimonial.author}
                className="w-12 h-12 rounded-full mr-4"
              />
              <div>
                <p className="font-semibold text-gray-900">{testimonial.author}</p>
                <p className="text-sm text-gray-600">{testimonial.position}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}