import React from 'react';
import { Check } from 'lucide-react';

const plans = [
  {
    name: "Starter",
    price: 500000,
    description: "Pour les petites entreprises",
    features: [
      "Diagnostic initial",
      "Plan d'action personnalisé",
      "Support email",
      "2 sessions de consultation"
    ]
  },
  {
    name: "Business",
    price: 1500000,
    description: "Pour les entreprises en croissance",
    features: [
      "Tout du plan Starter",
      "Analyse approfondie",
      "Support prioritaire",
      "Sessions mensuelles",
      "Rapports détaillés"
    ]
  },
  {
    name: "Enterprise",
    price: "Sur mesure",
    description: "Pour les grandes entreprises",
    features: [
      "Solution personnalisée",
      "Accompagnement dédié",
      "Support 24/7",
      "Consultations illimitées",
      "Analyses avancées",
      "Formation équipe"
    ]
  }
];

export function BusinessPricing() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Nos Forfaits</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 flex flex-col"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {plan.name}
            </h3>
            <p className="text-gray-600 mb-4">{plan.description}</p>
            <div className="mb-6">
              <span className="text-4xl font-bold text-primary-600">
                {typeof plan.price === 'number' 
                  ? new Intl.NumberFormat('fr-FR', {
                      style: 'currency',
                      currency: 'XOF',
                      maximumFractionDigits: 0
                    }).format(plan.price)
                  : plan.price}
              </span>
              {typeof plan.price === 'number' && <span className="text-gray-600">/mois</span>}
            </div>
            <ul className="space-y-3 mb-8 flex-grow">
              {plan.features.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
            <button className="w-full bg-primary-600 text-white py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors">
              Commencer
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}