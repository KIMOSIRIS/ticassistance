import React from 'react';
import { ClipboardList, Users, LineChart, CheckCircle } from 'lucide-react';

const steps = [
  {
    icon: <ClipboardList className="w-8 h-8" />,
    title: "Diagnostic Initial",
    description: "Analyse approfondie de votre entreprise et identification des opportunités"
  },
  {
    icon: <Users className="w-8 h-8" />,
    title: "Plan d'Action",
    description: "Élaboration d'une stratégie personnalisée et d'un plan d'action détaillé"
  },
  {
    icon: <LineChart className="w-8 h-8" />,
    title: "Mise en Œuvre",
    description: "Accompagnement dans l'implémentation des solutions recommandées"
  },
  {
    icon: <CheckCircle className="w-8 h-8" />,
    title: "Suivi et Ajustement",
    description: "Mesure des résultats et optimisation continue des performances"
  }
];

export function BusinessProcess() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Notre Processus</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {steps.map((step, index) => (
          <div key={index} className="relative">
            <div className="bg-white rounded-lg shadow-md p-6 text-center">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center text-primary-600 mx-auto mb-4">
                {step.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {step.title}
              </h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
            {index < steps.length - 1 && (
              <div className="hidden lg:block absolute top-1/2 right-0 w-full h-0.5 bg-primary-100 transform translate-x-1/2">
                <div className="absolute right-0 w-3 h-3 bg-primary-500 rounded-full transform translate-x-1/2 -translate-y-1/2"></div>
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}