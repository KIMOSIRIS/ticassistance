import React from 'react';
import { Calculator, BookOpen, Users, BarChart, FileSpreadsheet, Briefcase, Settings, Cloud } from 'lucide-react';

interface Sage100ServiceCard {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
  price: number;
}

const sage100Services: Sage100ServiceCard[] = [
  {
    icon: <Calculator className="w-6 h-6" />,
    title: "Installation et Configuration",
    description: "Installation complète de SAGE 100, paramétrage initial, configuration des modules comptables et commerciaux",
    features: [
      "Installation de SAGE 100",
      "Paramétrage des modules",
      "Migration des données",
      "Tests et validation"
    ],
    price: 350000
  },
  {
    icon: <BookOpen className="w-6 h-6" />,
    title: "Formation Utilisateurs",
    description: "Formation approfondie des utilisateurs sur tous les modules SAGE 100, support documentaire inclus",
    features: [
      "Formation sur site",
      "Support documentaire",
      "Exercices pratiques",
      "Suivi post-formation"
    ],
    price: 250000
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: "Gestion des Droits",
    description: "Configuration des profils utilisateurs, gestion des accès, sécurisation des données sensibles",
    features: [
      "Création des profils",
      "Gestion des accès",
      "Sécurité des données",
      "Audit des droits"
    ],
    price: 180000
  },
  {
    icon: <BarChart className="w-6 h-6" />,
    title: "Reporting et Tableaux de Bord",
    description: "Création de rapports personnalisés, tableaux de bord sur mesure, analyse des données",
    features: [
      "Rapports personnalisés",
      "Tableaux de bord",
      "Analyse financière",
      "Export des données"
    ],
    price: 200000
  },
  {
    icon: <Cloud className="w-6 h-6" />,
    title: "Solutions Cloud",
    description: "Déploiement et gestion de SAGE 100 en environnement cloud",
    features: [
      "Migration vers le cloud",
      "Sauvegarde automatique",
      "Accès distant sécurisé",
      "Haute disponibilité"
    ],
    price: 300000
  },
  {
    icon: <Settings className="w-6 h-6" />,
    title: "Support et Maintenance",
    description: "Support technique continu, mises à jour, maintenance préventive et corrective",
    features: [
      "Support technique 24/7",
      "Mises à jour régulières",
      "Maintenance préventive",
      "Assistance utilisateurs"
    ],
    price: 150000
  }
];

export function Sage100Services() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Services SAGE 100</h2>
          <p className="mt-4 text-xl text-gray-600">
            Solutions professionnelles d'administration et de gestion SAGE 100 pour entreprises
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sage100Services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {service.title}
              </h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <ul className="mb-6 space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                    <span className="w-1.5 h-1.5 bg-primary-600 rounded-full mr-2"></span>
                    {feature}
                  </li>
                ))}
              </ul>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-primary-600">
                  {new Intl.NumberFormat('fr-FR', {
                    style: 'currency',
                    currency: 'XOF'
                  }).format(service.price)}
                </span>
                <button className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors">
                  Commander
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-white rounded-lg shadow-md p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Avantages de nos services SAGE 100</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="flex items-start">
              <BookOpen className="w-8 h-8 text-primary-600 mr-4" />
              <div>
                <h4 className="text-lg font-semibold mb-2">Expertise Certifiée</h4>
                <p className="text-gray-600">Consultants certifiés SAGE avec plus de 10 ans d'expérience</p>
              </div>
            </div>
            <div className="flex items-start">
              <Users className="w-8 h-8 text-primary-600 mr-4" />
              <div>
                <h4 className="text-lg font-semibold mb-2">Support Personnalisé</h4>
                <p className="text-gray-600">Accompagnement sur mesure adapté à vos besoins</p>
              </div>
            </div>
            <div className="flex items-start">
              <Cloud className="w-8 h-8 text-primary-600 mr-4" />
              <div>
                <h4 className="text-lg font-semibold mb-2">Solutions Innovantes</h4>
                <p className="text-gray-600">Intégration des dernières technologies cloud</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}