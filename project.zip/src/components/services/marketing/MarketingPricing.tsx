import React from 'react';
import { Check } from 'lucide-react';

const plans = [
  {
    name: "Essentiel",
    price: 350000,
    description: "Pour les petites entreprises",
    features: [
      "Audit marketing digital",
      "Gestion 2 réseaux sociaux",
      "Optimisation SEO basique",
      "Rapport mensuel",
      "Support email"
    ]
  },
  {
    name: "Business",
    price: 750000,
    description: "Pour les entreprises en croissance",
    features: [
      "Tout du plan Essentiel",
      "Gestion 4 réseaux sociaux",
      "SEO avancé",
      "Campagnes publicitaires",
      "Email marketing",
      "Support prioritaire"
    ]
  },
  {
    name: "Premium",
    price: "Sur mesure",
    description: "Pour les grandes entreprises",
    features: [
      "Stratégie personnalisée",
      "Gestion tous réseaux",
      "SEO premium",
      "Publicité multi-canal",
      "Marketing automation",
      "Support dédié 24/7"
    ]
  }
];

export function MarketingPricing() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Nos Forfaits</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 flex flex-col"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {plan.name}
            </h3>
            <p className="text-gray-600 mb-4">{plan.description}</p>
            <div className="mb-6">
              <span className="text-4xl font-bold text-primary-600">
                {typeof plan.price === 'number' 
                  ? new Intl.NumberFormat('fr-FR', {
                      style: 'currency',
                      currency: 'XOF',
                      maximumFractionDigits: 0
                    }).format(plan.price)
                  : plan.price}
              </span>
              {typeof plan.price === 'number' && <span className="text-gray-600">/mois</span>}
            </div>
            <ul className="space-y-3 mb-8 flex-grow">
              {plan.features.map((feature, featureIndex) => (
                <li key={featureIndex} className="flex items-center space-x-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">{feature}</span>
                </li>
              ))}
            </ul>
            <button className="w-full bg-primary-600 text-white py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors">
              Commencer
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}