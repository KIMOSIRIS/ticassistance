import React from 'react';
import { Facebook, Instagram, Linkedin, Youtube, Globe, Mail } from 'lucide-react';

const channels = [
  {
    icon: <Facebook className="w-8 h-8" />,
    name: "Facebook",
    metrics: "2.9B utilisateurs actifs",
    description: "Idéal pour le B2C et la notoriété de marque"
  },
  {
    icon: <Instagram className="w-8 h-8" />,
    name: "Instagram",
    metrics: "1.4B utilisateurs actifs",
    description: "Parfait pour les marques visuelles et lifestyle"
  },
  {
    icon: <Linkedin className="w-8 h-8" />,
    name: "LinkedIn",
    metrics: "774M professionnels",
    description: "Optimal pour le B2B et le personal branding"
  },
  {
    icon: <Youtube className="w-8 h-8" />,
    name: "YouTube",
    metrics: "2.3B utilisateurs",
    description: "Excellent pour le contenu vidéo et tutoriels"
  },
  {
    icon: <Globe className="w-8 h-8" />,
    name: "SEO",
    metrics: "93% du trafic web",
    description: "Essentiel pour la visibilité long terme"
  },
  {
    icon: <Mail className="w-8 h-8" />,
    name: "Email",
    metrics: "4.3B utilisateurs",
    description: "Crucial pour la fidélisation client"
  }
];

export function MarketingChannels() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Canaux Marketing</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {channels.map((channel, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mr-4">
                {channel.icon}
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-900">{channel.name}</h3>
                <p className="text-sm text-primary-600">{channel.metrics}</p>
              </div>
            </div>
            <p className="text-gray-600">{channel.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}