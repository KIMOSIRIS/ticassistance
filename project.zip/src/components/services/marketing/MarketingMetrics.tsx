import React from 'react';
import { TrendingUp, Users, ShoppingCart, Eye } from 'lucide-react';

const metrics = [
  {
    icon: <TrendingUp className="w-8 h-8" />,
    title: "Trafic Web",
    value: "+150%",
    description: "Augmentation moyenne du trafic"
  },
  {
    icon: <Users className="w-8 h-8" />,
    title: "Engagement",
    value: "+200%",
    description: "Hausse de l'engagement social"
  },
  {
    icon: <ShoppingCart className="w-8 h-8" />,
    title: "Conversions",
    value: "+80%",
    description: "Amélioration du taux de conversion"
  },
  {
    icon: <Eye className="w-8 h-8" />,
    title: "Visibilité",
    value: "Top 3",
    description: "Positionnement SEO moyen"
  }
];

export function MarketingMetrics() {
  return (
    <section className="bg-primary-600 rounded-lg p-8 text-white">
      <h2 className="text-2xl font-bold mb-8 text-center">Résultats Moyens Obtenus</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {metrics.map((metric, index) => (
          <div key={index} className="text-center">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-primary-600 mx-auto mb-4">
              {metric.icon}
            </div>
            <h3 className="text-xl font-semibold mb-2">{metric.title}</h3>
            <p className="text-3xl font-bold mb-2">{metric.value}</p>
            <p className="text-primary-100">{metric.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}