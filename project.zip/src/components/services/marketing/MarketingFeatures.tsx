import React from 'react';
import { Search, BarChart2, Mail, MessageSquare, Target, TrendingUp } from 'lucide-react';

const features = [
  {
    icon: <Search className="w-6 h-6" />,
    title: "SEO",
    description: "Optimisation pour les moteurs de recherche et visibilité organique"
  },
  {
    icon: <BarChart2 className="w-6 h-6" />,
    title: "Marketing Analytics",
    description: "Analyse de données et rapports de performance détaillés"
  },
  {
    icon: <Mail className="w-6 h-6" />,
    title: "Email Marketing",
    description: "Campagnes d'emailing personnalisées et automation marketing"
  },
  {
    icon: <MessageSquare className="w-6 h-6" />,
    title: "Réseaux Sociaux",
    description: "Gestion et animation de vos réseaux sociaux"
  },
  {
    icon: <Target className="w-6 h-6" />,
    title: "Publicité en Ligne",
    description: "Campagnes publicitaires ciblées sur Google et réseaux sociaux"
  },
  {
    icon: <TrendingUp className="w-6 h-6" />,
    title: "Growth Marketing",
    description: "Stratégies d'acquisition et de fidélisation clients"
  }
];

export function MarketingFeatures() {
  return (
    <section>
      <h2 className="text-2xl font-bold text-gray-900 mb-8">Nos Services Marketing</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature, index) => (
          <div
            key={index}
            className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300"
          >
            <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
              {feature.icon}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              {feature.title}
            </h3>
            <p className="text-gray-600">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}