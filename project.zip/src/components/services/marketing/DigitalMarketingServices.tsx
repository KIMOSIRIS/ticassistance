import React from 'react';
import { MarketingFeatures } from './MarketingFeatures';
import { MarketingChannels } from './MarketingChannels';
import { MarketingProcess } from './MarketingProcess';
import { MarketingPricing } from './MarketingPricing';
import { MarketingMetrics } from './MarketingMetrics';
import { MarketingTestimonials } from './MarketingTestimonials';

export function DigitalMarketingServices() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Marketing Digital
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Boostez votre visibilité en ligne et atteignez vos objectifs commerciaux
            avec nos stratégies marketing innovantes
          </p>
        </div>

        <div className="space-y-16">
          <MarketingFeatures />
          <MarketingChannels />
          <MarketingProcess />
          <MarketingMetrics />
          <MarketingPricing />
          <MarketingTestimonials />
        </div>
      </div>
    </div>
  );
}