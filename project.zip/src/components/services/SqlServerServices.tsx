import React from 'react';
import { Database, Shield, LineChart, Settings, Server, Code } from 'lucide-react';

interface SqlServiceCard {
  icon: React.ReactNode;
  title: string;
  description: string;
  price: number;
}

const sqlServices: SqlServiceCard[] = [
  {
    icon: <Database className="w-6 h-6" />,
    title: "Installation et Configuration",
    description: "Installation et configuration complète de SQL Server, mise en place des bonnes pratiques et optimisation des performances",
    price: 250000
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Sécurité et Audit",
    description: "Audit de sécurité, gestion des accès, encryption des données et mise en place des politiques de sécurité",
    price: 200000
  },
  {
    icon: <LineChart className="w-6 h-6" />,
    title: "Optimisation des Performances",
    description: "Analyse et optimisation des requêtes, indexation, maintenance des performances et monitoring",
    price: 180000
  },
  {
    icon: <Settings className="w-6 h-6" />,
    title: "Maintenance et Support",
    description: "Maintenance préventive, backup et restauration, monitoring 24/7 et support technique",
    price: 150000
  },
  {
    icon: <Server className="w-6 h-6" />,
    title: "Migration et Mise à Niveau",
    description: "Migration vers les nouvelles versions, consolidation des bases de données et mise à niveau des systèmes",
    price: 300000
  },
  {
    icon: <Code className="w-6 h-6" />,
    title: "Développement T-SQL",
    description: "Développement de procédures stockées, triggers, fonctions et optimisation du code T-SQL",
    price: 200000
  }
];

export function SqlServerServices() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Services SQL Server</h2>
          <p className="mt-4 text-xl text-gray-600">
            Solutions professionnelles d'administration et d'optimisation SQL Server
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sqlServices.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {service.title}
              </h3>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <div className="flex justify-between items-center">
                <span className="text-lg font-bold text-primary-600">
                  {new Intl.NumberFormat('fr-FR', {
                    style: 'currency',
                    currency: 'XOF'
                  }).format(service.price)}
                </span>
                <button className="bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors">
                  Commander
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}