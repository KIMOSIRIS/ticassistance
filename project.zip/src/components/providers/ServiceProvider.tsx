import React from 'react';
import { MapPin, Phone, Star } from 'lucide-react';
import { formatPhoneNumber } from '../../utils/phoneUtils';

interface ServiceProviderProps {
  name: string;
  service: string;
  rating: number;
  phone: string;
  distance: number;
  image: string;
}

export function ServiceProvider({ name, service, rating, phone, distance, image }: ServiceProviderProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center space-x-4">
        <img
          src={image}
          alt={name}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900">{name}</h3>
          <p className="text-gray-600">{service}</p>
          <div className="flex items-center space-x-4 mt-2">
            <div className="flex items-center text-primary-500">
              <Star className="w-4 h-4 fill-current" />
              <span className="ml-1 text-gray-700">{rating}</span>
            </div>
            <div className="flex items-center text-gray-600">
              <MapPin className="w-4 h-4" />
              <span className="ml-1">{distance} km</span>
            </div>
          </div>
        </div>
        <a
          href={`tel:${phone}`}
          className="flex items-center space-x-2 bg-accent-100 text-accent-700 px-4 py-2 rounded-lg hover:bg-accent-200 transition-colors"
        >
          <Phone className="w-4 h-4" />
          <span>{formatPhoneNumber(phone)}</span>
        </a>
      </div>
    </div>
  );
}