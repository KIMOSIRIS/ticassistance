import React from 'react';
import { Server, Database, Shield, Award, Phone, Mail, MapPin } from 'lucide-react';

interface ExpertProfileProps {
  expert: {
    name: string;
    title: string;
    phone: string;
    email?: string;
    location?: string;
    specialties: string[];
    certifications: string[];
    experience: string[];
  };
}

export function ExpertProfile({ expert }: ExpertProfileProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-8">
      <div className="flex flex-col md:flex-row items-start gap-8">
        <div className="w-full md:w-1/3">
          <div className="aspect-square rounded-lg bg-primary-100 flex items-center justify-center">
            <Server className="w-24 h-24 text-primary-600" />
          </div>
          <div className="mt-6 space-y-4">
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-primary-600" />
              <a href={`tel:${expert.phone}`} className="text-gray-700 hover:text-primary-600">
                {expert.phone}
              </a>
            </div>
            {expert.email && (
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-primary-600" />
                <a href={`mailto:${expert.email}`} className="text-gray-700 hover:text-primary-600">
                  {expert.email}
                </a>
              </div>
            )}
            {expert.location && (
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-primary-600" />
                <span className="text-gray-700">{expert.location}</span>
              </div>
            )}
          </div>
        </div>

        <div className="w-full md:w-2/3 space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{expert.name}</h1>
            <p className="text-xl text-primary-600 mt-2">{expert.title}</p>
          </div>

          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Database className="w-5 h-5" />
              Spécialités
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {expert.specialties.map((specialty, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary-600 rounded-full" />
                  <span className="text-gray-700">{specialty}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <Award className="w-5 h-5" />
              Certifications
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {expert.certifications.map((certification, index) => (
                <div key={index} className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-primary-600" />
                  <span className="text-gray-700">{certification}</span>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Expérience</h2>
            <div className="space-y-4">
              {expert.experience.map((exp, index) => (
                <div key={index} className="flex items-start gap-2">
                  <div className="w-2 h-2 bg-primary-600 rounded-full mt-2" />
                  <span className="text-gray-700">{exp}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}