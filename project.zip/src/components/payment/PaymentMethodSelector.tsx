import React from 'react';
import { CreditCard } from 'lucide-react';

interface PaymentMethod {
  id: string;
  name: string;
  logo: string;
  description: string;
}

interface PaymentMethodSelectorProps {
  selectedMethod: string;
  onMethodSelect: (methodId: string) => void;
}

const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'orange_money',
    name: 'Orange Money',
    logo: 'https://upload.wikimedia.org/wikipedia/fr/thumb/8/84/Orange_Money.png/220px-Orange_Money.png',
    description: 'Payer avec votre compte Orange Money',
  },
  {
    id: 'wave',
    name: 'Wave',
    logo: 'https://wave.com/static/wave-logo.png',
    description: 'Payer avec votre compte Wave',
  },
];

export function PaymentMethodSelector({ selectedMethod, onMethodSelect }: PaymentMethodSelectorProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium text-gray-900">
        Choisissez votre méthode de paiement
      </h3>
      <div className="grid grid-cols-1 gap-4">
        {PAYMENT_METHODS.map((method) => (
          <label
            key={method.id}
            className={`
              relative flex cursor-pointer rounded-lg border p-4 shadow-sm focus:outline-none
              ${selectedMethod === method.id
                ? 'border-primary-500 ring-2 ring-primary-500'
                : 'border-gray-300'
              }
            `}
          >
            <input
              type="radio"
              name="payment-method"
              className="sr-only"
              value={method.id}
              checked={selectedMethod === method.id}
              onChange={() => onMethodSelect(method.id)}
            />
            <div className="flex w-full items-center justify-between">
              <div className="flex items-center">
                <div className="h-10 w-10 flex-shrink-0">
                  <img
                    src={method.logo}
                    alt={method.name}
                    className="h-full w-full object-contain"
                  />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900">
                    {method.name}
                  </p>
                  <p className="text-sm text-gray-500">
                    {method.description}
                  </p>
                </div>
              </div>
              {selectedMethod === method.id && (
                <div className="text-primary-600">
                  <CreditCard className="h-5 w-5" />
                </div>
              )}
            </div>
          </label>
        ))}
      </div>
    </div>
  );
}