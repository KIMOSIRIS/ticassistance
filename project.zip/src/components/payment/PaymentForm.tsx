import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Phone, CreditCard, Loader } from 'lucide-react';
import { OrangeMoneyService } from '../../services/orangeMoney';
import { WavePaymentService } from '../../services/wavePayment';
import { validatePhoneNumber } from '../../utils/phoneUtils';
import { PaymentMethodSelector } from './PaymentMethodSelector';

const paymentSchema = z.object({
  amount: z.number().min(100, 'Le montant minimum est de 100 FCFA'),
  phoneNumber: z.string().refine(
    (phone) => validatePhoneNumber(phone, 'CI'),
    'Numéro de téléphone invalide'
  ),
  description: z.string().min(3, 'Description requise'),
});

type PaymentFormData = z.infer<typeof paymentSchema>;

const orangeMoneyService = new OrangeMoneyService({
  merchantId: import.meta.env.VITE_ORANGE_MONEY_MERCHANT_ID,
  merchantKey: import.meta.env.VITE_ORANGE_MONEY_MERCHANT_KEY,
  apiEndpoint: import.meta.env.VITE_ORANGE_MONEY_API_ENDPOINT,
});

const wavePaymentService = new WavePaymentService({
  apiKey: import.meta.env.VITE_WAVE_API_KEY,
  merchantId: import.meta.env.VITE_WAVE_MERCHANT_ID,
  apiEndpoint: import.meta.env.VITE_WAVE_API_ENDPOINT,
});

export function PaymentForm() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('orange_money');

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<PaymentFormData>({
    resolver: zodResolver(paymentSchema),
  });

  const onSubmit = async (data: PaymentFormData) => {
    setLoading(true);
    setError(null);
    
    try {
      let response;
      
      if (paymentMethod === 'wave') {
        response = await wavePaymentService.initiatePayment({
          amount: data.amount,
          currency: 'XOF',
          customerPhone: data.phoneNumber,
          description: data.description,
        });
      } else {
        response = await orangeMoneyService.initiatePayment({
          amount: data.amount,
          currency: 'XOF',
          orderId: `ORDER-${Date.now()}`,
          customerPhone: data.phoneNumber,
          description: data.description,
        });
      }

      if (response.status === 'success' && response.paymentUrl) {
        window.location.href = response.paymentUrl;
      } else {
        setError(response.error || 'Une erreur est survenue');
      }
    } catch (err) {
      setError('Le paiement a échoué. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-center mb-6">
        <div className="bg-primary-100 p-3 rounded-full">
          <CreditCard className="w-6 h-6 text-primary-600" />
        </div>
      </div>

      <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">
        Paiement
      </h2>

      <PaymentMethodSelector
        selectedMethod={paymentMethod}
        onMethodSelect={setPaymentMethod}
      />

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 mt-8">
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Montant (FCFA)
          </label>
          <input
            type="number"
            {...register('amount', { valueAsNumber: true })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          />
          {errors.amount && (
            <p className="mt-1 text-sm text-red-600">{errors.amount.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Numéro de téléphone
          </label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Phone className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="tel"
              {...register('phoneNumber')}
              className="block w-full pl-10 rounded-md border-gray-300 focus:border-primary-500 focus:ring-primary-500"
              placeholder="+225 XX XX XX XX XX"
            />
          </div>
          {errors.phoneNumber && (
            <p className="mt-1 text-sm text-red-600">{errors.phoneNumber.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">
            Description
          </label>
          <textarea
            {...register('description')}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          />
          {errors.description && (
            <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
          )}
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-md p-4">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
        >
          {loading ? (
            <Loader className="w-5 h-5 animate-spin" />
          ) : (
            `Payer avec ${paymentMethod === 'wave' ? 'Wave' : 'Orange Money'}`
          )}
        </button>
      </form>
    </div>
  );
}