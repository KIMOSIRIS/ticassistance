import React, { useEffect, useState } from 'react';
import { Check, X, Loader } from 'lucide-react';
import { OrangeMoneyService } from '../../services/orangeMoney';
import { WavePaymentService } from '../../services/wavePayment';

interface PaymentStatusProps {
  transactionId: string;
  paymentMethod: 'orange_money' | 'wave';
  onComplete?: (success: boolean) => void;
}

const orangeMoneyService = new OrangeMoneyService({
  merchantId: import.meta.env.VITE_ORANGE_MONEY_MERCHANT_ID,
  merchantKey: import.meta.env.VITE_ORANGE_MONEY_MERCHANT_KEY,
  apiEndpoint: import.meta.env.VITE_ORANGE_MONEY_API_ENDPOINT,
});

const wavePaymentService = new WavePaymentService({
  apiKey: import.meta.env.VITE_WAVE_API_KEY,
  merchantId: import.meta.env.VITE_WAVE_MERCHANT_ID,
  apiEndpoint: import.meta.env.VITE_WAVE_API_ENDPOINT,
});

export function PaymentStatus({ transactionId, paymentMethod, onComplete }: PaymentStatusProps) {
  const [status, setStatus] = useState<'pending' | 'success' | 'error'>('pending');
  const [message, setMessage] = useState('Vérification du paiement en cours...');

  useEffect(() => {
    const checkPaymentStatus = async () => {
      try {
        const service = paymentMethod === 'wave' ? wavePaymentService : orangeMoneyService;
        const response = await service.verifyPayment(transactionId);
        
        if (response.status === 'completed') {
          setStatus('success');
          setMessage('Paiement effectué avec succès !');
          onComplete?.(true);
        } else if (response.status === 'error') {
          setStatus('error');
          setMessage(response.error || 'Le paiement a échoué.');
          onComplete?.(false);
        }
      } catch (error) {
        setStatus('error');
        setMessage('Une erreur est survenue lors de la vérification du paiement.');
        onComplete?.(false);
      }
    };

    const interval = setInterval(checkPaymentStatus, 5000);
    return () => clearInterval(interval);
  }, [transactionId, paymentMethod, onComplete]);

  return (
    <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-center mb-4">
        {status === 'pending' && (
          <div className="bg-yellow-100 p-3 rounded-full">
            <Loader className="w-6 h-6 text-yellow-600 animate-spin" />
          </div>
        )}
        {status === 'success' && (
          <div className="bg-green-100 p-3 rounded-full">
            <Check className="w-6 h-6 text-green-600" />
          </div>
        )}
        {status === 'error' && (
          <div className="bg-red-100 p-3 rounded-full">
            <X className="w-6 h-6 text-red-600" />
          </div>
        )}
      </div>

      <h3 className="text-lg font-medium text-center text-gray-900 mb-2">
        {status === 'pending' && 'Paiement en cours'}
        {status === 'success' && 'Paiement réussi'}
        {status === 'error' && 'Échec du paiement'}
      </h3>

      <p className="text-center text-gray-600">{message}</p>

      {status !== 'pending' && (
        <button
          onClick={() => window.location.reload()}
          className="mt-6 w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
        >
          Retour à l'accueil
        </button>
      )}
    </div>
  );
}