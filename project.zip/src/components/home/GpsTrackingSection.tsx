import React from 'react';
import { Navigation, MapPin, Route, Clock, Shield, BarChart } from 'lucide-react';
import { Link } from 'react-router-dom';

const features = [
  {
    icon: <MapPin className="w-6 h-6" />,
    title: "Suivi en Temps Réel",
    description: "Localisez vos véhicules avec précision en temps réel"
  },
  {
    icon: <Route className="w-6 h-6" />,
    title: "Optimisation d'Itinéraires",
    description: "Réduisez vos coûts avec des trajets optimisés"
  },
  {
    icon: <Clock className="w-6 h-6" />,
    title: "Historique Détaillé",
    description: "Accédez à l'historique complet des déplacements"
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: "Sécurité Avancée",
    description: "Protection et surveillance 24/7 de votre flotte"
  },
  {
    icon: <BarChart className="w-6 h-6" />,
    title: "Analyses & Rapports",
    description: "Statistiques détaillées et rapports personnalisés"
  }
];

export function GpsTrackingSection() {
  return (
    <section className="py-16 bg-gradient-to-b from-primary-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Solution de Géolocalisation GPS
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Optimisez la gestion de votre flotte avec notre plateforme de géolocalisation avancée
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center text-primary-600 mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-primary-600 rounded-2xl p-8 text-white text-center">
          <div className="max-w-3xl mx-auto">
            <Navigation className="w-12 h-12 mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-4">
              Prêt à optimiser votre flotte ?
            </h3>
            <p className="text-primary-100 mb-8">
              Découvrez comment notre solution de géolocalisation peut transformer 
              la gestion de vos véhicules et réduire vos coûts opérationnels.
            </p>
            <Link
              to="/services/gps-tracking"
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-primary-600 bg-white hover:bg-primary-50 transition-colors duration-300"
            >
              Découvrir la Solution GPS
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}