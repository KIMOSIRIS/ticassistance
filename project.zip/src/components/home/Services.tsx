import React from 'react';
import { ServiceCard } from './ServiceCard';
import { mainServices } from '../services/constants/services';

export function Services() {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Nos Services</h2>
          <p className="mt-4 text-xl text-gray-600">
            Des solutions professionnelles adaptées à vos besoins
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {mainServices.map((service) => (
            <ServiceCard
              key={service.title}
              title={service.title}
              description={service.description}
              icon={<service.icon className="w-6 h-6" />}
              path={service.path}
            />
          ))}
        </div>
      </div>
    </section>
  );
}