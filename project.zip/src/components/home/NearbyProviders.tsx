import React from 'react';
import { ServiceProvider } from '../providers/ServiceProvider';
import { useGeolocation } from '../../hooks/useGeolocation';

const MOCK_PROVIDERS = [
  {
    id: 1,
    name: 'Marie Dubois',
    service: 'Conseil Business',
    rating: 4.8,
    phone: '+33123456789',
    distance: 2.5,
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=128&h=128&q=80'
  },
  {
    id: 2,
    name: 'Jean Martin',
    service: 'Développement Web',
    rating: 4.9,
    phone: '+33187654321',
    distance: 3.7,
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=128&h=128&q=80'
  }
];

export function NearbyProviders() {
  const { loading, error } = useGeolocation();

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900">Prestataires à Proximité</h2>
          <p className="mt-4 text-xl text-gray-600">
            {loading ? 'Recherche des prestataires...' : 
             error ? 'Impossible de trouver votre position' :
             'Découvrez les meilleurs prestataires près de chez vous'}
          </p>
        </div>
        <div className="space-y-6">
          {MOCK_PROVIDERS.map(provider => (
            <ServiceProvider key={provider.id} {...provider} />
          ))}
        </div>
      </div>
    </section>
  );
}