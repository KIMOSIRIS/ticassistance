import React from 'react';
import { useNavigate } from 'react-router-dom';

export function Hero() {
  const navigate = useNavigate();

  return (
    <div className="relative bg-primary-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-white sm:text-5xl md:text-6xl">
            <span className="block">Solutions IT Professionnelles</span>
            <span className="block">Expertise & Innovation</span>
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-primary-100 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            TICASSISTANCE vous accompagne dans tous vos projets IT avec des experts certifiés.
            Solutions sur mesure, support réactif, excellence technique.
          </p>
          <div className="mt-10 flex justify-center gap-4">
            <button 
              onClick={() => navigate('/discover-services')}
              className="bg-accent-500 text-white font-semibold px-8 py-3 rounded-lg hover:bg-accent-600 transition-colors"
            >
              Découvrir nos Services
            </button>
            <button 
              onClick={() => navigate('/services/gps-tracking')}
              className="bg-white text-primary-600 font-semibold px-8 py-3 rounded-lg hover:bg-primary-50 transition-colors"
            >
              Solution GPS
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}