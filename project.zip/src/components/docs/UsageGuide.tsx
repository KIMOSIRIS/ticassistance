import React from 'react';
import { Book, Users, ShieldCheck, Settings, HelpCircle, Navigation, Bell, Map } from 'lucide-react';

export function UsageGuide() {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Guide d'Utilisation</h2>

      <div className="space-y-8">
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Users className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Gestion des Utilisateurs</h3>
          </div>
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900">Création de compte</h4>
            <ol className="list-decimal list-inside space-y-2 text-gray-600">
              <li>Cliquez sur "Se connecter" en haut à droite</li>
              <li>Sélectionnez "Créer un compte"</li>
              <li>Remplissez le formulaire avec vos informations</li>
              <li>Validez votre email via le lien reçu</li>
            </ol>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Navigation className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Suivi GPS</h3>
          </div>
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900">Fonctionnalités de Base</h4>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Suivi en temps réel des véhicules</li>
              <li>Historique des trajets</li>
              <li>Alertes de batterie faible</li>
              <li>Zones de géofencing (version Premium)</li>
            </ul>
            
            <h4 className="font-medium text-gray-900 mt-6">Configuration</h4>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Définissez l'intervalle de mise à jour</li>
              <li>Configurez les seuils d'alerte</li>
              <li>Personnalisez l'affichage de la carte</li>
            </ul>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Bell className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Notifications</h3>
          </div>
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900">Types d'Alertes</h4>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Alertes de batterie faible</li>
              <li>Notifications de sortie de zone</li>
              <li>Alertes de maintenance</li>
              <li>Rapports quotidiens</li>
            </ul>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Map className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Gestion de la Carte</h3>
          </div>
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900">Personnalisation</h4>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Ajustement du niveau de zoom</li>
              <li>Sélection des couches de carte</li>
              <li>Définition des zones de géofencing</li>
              <li>Filtres d'affichage des véhicules</li>
            </ul>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <ShieldCheck className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Sécurité</h3>
          </div>
          <div className="space-y-4">
            <h4 className="font-medium text-gray-900">Recommandations</h4>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              <li>Utilisez un mot de passe fort et unique</li>
              <li>Activez l'authentification à deux facteurs</li>
              <li>Ne partagez jamais vos identifiants</li>
              <li>Vérifiez régulièrement l'historique des connexions</li>
            </ul>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <HelpCircle className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Support</h3>
          </div>
          <div className="space-y-4">
            <p className="text-gray-600">
              Pour toute assistance, contactez notre équipe support :
            </p>
            <ul className="space-y-2 text-gray-600">
              <li>Email: support@ticassistance.com</li>
              <li>Téléphone: +225 05 74 08 74 69</li>
              <li>Horaires: Lun-Ven 8h-18h</li>
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}