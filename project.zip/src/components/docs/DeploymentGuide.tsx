import React from 'react';
import { Server, Cloud, Terminal, CheckCircle, AlertCircle } from 'lucide-react';

export function DeploymentGuide() {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Guide de Déploiement</h2>

      <div className="space-y-8">
        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Server className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Prérequis</h3>
          </div>
          <ul className="space-y-2 text-gray-600">
            <li className="flex items-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              Node.js version 14 ou supérieure
            </li>
            <li className="flex items-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              npm ou yarn installé
            </li>
            <li className="flex items-center">
              <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
              Git pour le contrôle de version
            </li>
          </ul>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Terminal className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Installation</h3>
          </div>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-mono mb-2">1. Cloner le repository</p>
              <code className="block bg-gray-800 text-white p-3 rounded">
                git clone https://github.com/votre-repo/ticassistance.git
              </code>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-mono mb-2">2. Installer les dépendances</p>
              <code className="block bg-gray-800 text-white p-3 rounded">
                cd ticassistance<br />
                npm install
              </code>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-mono mb-2">3. Configurer les variables d'environnement</p>
              <code className="block bg-gray-800 text-white p-3 rounded">
                cp .env.example .env<br />
                # Éditer .env avec vos configurations
              </code>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center mb-4">
            <Cloud className="w-6 h-6 text-primary-600 mr-3" />
            <h3 className="text-xl font-semibold">Déploiement</h3>
          </div>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-mono mb-2">1. Build de production</p>
              <code className="block bg-gray-800 text-white p-3 rounded">
                npm run build
              </code>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <p className="text-sm font-mono mb-2">2. Démarrer en production</p>
              <code className="block bg-gray-800 text-white p-3 rounded">
                npm run start
              </code>
            </div>

            <div className="bg-primary-50 border-l-4 border-primary-600 p-4">
              <div className="flex items-center">
                <AlertCircle className="w-5 h-5 text-primary-600 mr-2" />
                <p className="text-primary-700 font-medium">Note importante</p>
              </div>
              <p className="mt-2 text-primary-600">
                Assurez-vous que toutes les variables d'environnement sont correctement configurées avant le déploiement.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}