import React, { useState } from 'react';
import { Search, User, ShoppingCart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth0 } from '@auth0/auth0-react';
import { SearchModal } from '../search/SearchModal';
import { CartModal } from '../cart/CartModal';
import { AuthModal } from '../auth/AuthModal';
import { useCartStore } from '../../store/cartStore';

export function Header() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const { isAuthenticated, user } = useAuth0();
  const cartItems = useCartStore((state) => state.items);

  return (
    <>
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <Link to="/" className="text-2xl font-bold text-primary-600">
                TICASSISTANCE
              </Link>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <Link to="/services" className="text-gray-700 hover:text-primary-600 transition-colors">Services</Link>
              <Link to="/experts" className="text-gray-700 hover:text-primary-600 transition-colors">Experts</Link>
              <Link to="/about" className="text-gray-700 hover:text-primary-600 transition-colors">À Propos</Link>
              <Link to="/contact" className="text-gray-700 hover:text-primary-600 transition-colors">Contact</Link>
              <Link to="/documentation" className="text-gray-700 hover:text-primary-600 transition-colors">Documentation</Link>
            </nav>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setIsSearchOpen(true)}
                className="p-2 hover:bg-primary-50 rounded-full"
              >
                <Search className="w-5 h-5 text-primary-600" />
              </button>
              
              <button
                onClick={() => isAuthenticated ? null : setIsAuthOpen(true)}
                className="p-2 hover:bg-primary-50 rounded-full relative"
              >
                {isAuthenticated && user?.picture ? (
                  <img
                    src={user.picture}
                    alt={user.name}
                    className="w-8 h-8 rounded-full"
                  />
                ) : (
                  <User className="w-5 h-5 text-primary-600" />
                )}
              </button>

              <button
                onClick={() => setIsCartOpen(true)}
                className="p-2 hover:bg-primary-50 rounded-full relative"
              >
                <ShoppingCart className="w-5 h-5 text-primary-600" />
                {cartItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-accent-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                    {cartItems.length}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <CartModal isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </>
  );
}