import React from 'react';
import { MapPin, Phone } from 'lucide-react';
import { useGeolocation } from '../../hooks/useGeolocation';

export function LocationBanner() {
  const { latitude, longitude, error, loading } = useGeolocation();

  return (
    <div className="bg-primary-600 text-white py-2">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <MapPin className="w-4 h-4" />
            {loading ? (
              <span>Localisation en cours...</span>
            ) : error ? (
              <span>{error}</span>
            ) : (
              <span>
                {latitude?.toFixed(4)}°, {longitude?.toFixed(4)}°
              </span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Phone className="w-4 h-4" />
            <a href="tel:+2250574087469" className="hover:underline">
              +225 05 74 08 74 69
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}