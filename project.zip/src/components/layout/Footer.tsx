import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-white border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-primary-600 mb-4">TICASSISTANCE</h3>
            <p className="text-gray-600">
              Votre partenaire de confiance pour tous vos besoins en services IT professionnels.
            </p>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-gray-900 uppercase mb-4">Services</h4>
            <ul className="space-y-2">
              <li><Link to="/services/windows-server" className="text-gray-700 hover:text-primary-600 transition-colors">Windows Server</Link></li>
              <li><Link to="/services/sql-server" className="text-gray-700 hover:text-primary-600 transition-colors">SQL Server</Link></li>
              <li><Link to="/services/sage100" className="text-gray-700 hover:text-primary-600 transition-colors">SAGE 100</Link></li>
              <li><Link to="/services" className="text-gray-700 hover:text-primary-600 transition-colors">Tous les services</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-gray-900 uppercase mb-4">Entreprise</h4>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-gray-700 hover:text-primary-600 transition-colors">À Propos</Link></li>
              <li><Link to="/contact" className="text-gray-700 hover:text-primary-600 transition-colors">Contact</Link></li>
              <li><Link to="/terms" className="text-gray-700 hover:text-primary-600 transition-colors">Conditions d'utilisation</Link></li>
              <li><Link to="/privacy" className="text-gray-700 hover:text-primary-600 transition-colors">Politique de confidentialité</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-gray-900 uppercase mb-4">Suivez-nous</h4>
            <div className="flex space-x-4">
              <a href="https://facebook.com/ticassistance" className="text-gray-400 hover:text-primary-600">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="https://twitter.com/ticassistance" className="text-gray-400 hover:text-primary-600">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="https://instagram.com/ticassistance" className="text-gray-400 hover:text-primary-600">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="mailto:contact@ticassistance.com" className="text-gray-400 hover:text-primary-600">
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-gray-200">
          <p className="text-center text-gray-500">
            © {new Date().getFullYear()} TICASSISTANCE. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
}