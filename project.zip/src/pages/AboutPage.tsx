import React from 'react';
import { Building2, Users, Shield, Trophy } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">À Propos de ServPro</h1>
          <p className="text-xl text-gray-600">
            Votre partenaire de confiance pour tous vos besoins en services professionnels
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {[
            {
              icon: <Building2 className="w-8 h-8" />,
              title: "Excellence",
              description: "Des services de haute qualité garantis par nos experts"
            },
            {
              icon: <Users className="w-8 h-8" />,
              title: "Communauté",
              description: "Une communauté grandissante de professionnels qualifiés"
            },
            {
              icon: <Shield className="w-8 h-8" />,
              title: "Sécurité",
              description: "Vos transactions et données personnelles sont protégées"
            },
            {
              icon: <Trophy className="w-8 h-8" />,
              title: "Satisfaction",
              description: "La satisfaction client est notre priorité absolue"
            }
          ].map((item, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="text-primary-600 flex justify-center mb-4">
                {item.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
              <p className="text-gray-600">{item.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-lg shadow-md p-8 mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Notre Histoire</h2>
          <p className="text-gray-600 mb-4">
            Fondée avec la vision de transformer l'accès aux services professionnels, ServPro 
            s'est développée pour devenir une plateforme leader dans la mise en relation entre 
            clients et prestataires de services qualifiés.
          </p>
          <p className="text-gray-600">
            Notre engagement envers l'excellence et l'innovation continue nous permet d'offrir 
            une expérience utilisateur exceptionnelle, tout en contribuant au développement 
            économique local.
          </p>
        </div>

        <div className="bg-primary-600 text-white rounded-lg p-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6">Rejoignez Notre Réseau</h2>
            <p className="text-lg mb-8">
              Devenez membre de notre communauté grandissante de professionnels
            </p>
            <button className="bg-white text-primary-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Devenir Prestataire
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}