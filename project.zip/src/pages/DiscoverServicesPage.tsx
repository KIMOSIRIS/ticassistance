import React from 'react';
import { ServiceCategory } from '../components/services/ServiceCategory';
import { ServiceHighlight } from '../components/services/ServiceHighlight';
import { ServiceTestimonial } from '../components/services/ServiceTestimonial';
import { ServicePricing } from '../components/services/ServicePricing';

export function DiscoverServicesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Découvrez Nos Services Professionnels
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Une gamme complète de services professionnels pour répondre à tous vos besoins
            d'entreprise avec excellence et fiabilité.
          </p>
        </div>

        <ServiceCategory />
        <ServiceHighlight />
        <ServiceTestimonial />
        <ServicePricing />
      </div>
    </div>
  );
}