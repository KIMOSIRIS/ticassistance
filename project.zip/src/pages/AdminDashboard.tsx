import React from 'react';
import { Shield } from 'lucide-react';
import { Analytics } from '../components/admin/Analytics';
import { UserManager } from '../components/admin/UserManager';
import { ServiceManager } from '../components/admin/ServiceManager';
import { ThemeManager } from '../components/admin/ThemeManager';
import { GpsTracking } from '../components/admin/GpsTracking';

export function AdminDashboard() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Shield className="w-8 h-8 text-primary-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-900">
              Tableau de Bord Administrateur
            </h1>
          </div>
        </div>

        <div className="space-y-6">
          <Analytics />
          <GpsTracking />
          <UserManager />
          <ServiceManager />
          <ThemeManager />
        </div>
      </div>
    </div>
  );
}