import React from 'react';
import { ServiceLayout } from '../components/services/common/ServiceLayout';
import { ServiceHeader } from '../components/services/common/ServiceHeader';
import { Services } from '../components/home/Services';

export function ServicesPage() {
  return (
    <ServiceLayout>
      <ServiceHeader
        title="Nos Services"
        description="Des solutions professionnelles complètes pour répondre à tous vos besoins informatiques"
      />
      <Services />
    </ServiceLayout>
  );
}