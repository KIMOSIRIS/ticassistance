import React from 'react';
import { DeploymentGuide } from '../components/docs/DeploymentGuide';
import { UsageGuide } from '../components/docs/UsageGuide';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/Tabs';

export function DocumentationPage() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Documentation</h1>
          <p className="text-xl text-gray-600">
            Guide complet pour le déploiement et l'utilisation de la plateforme
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6" aria-label="Tabs">
              <button
                className="border-primary-500 text-primary-600 py-4 px-1 border-b-2 font-medium text-sm"
                aria-current="page"
              >
                Guide de Déploiement
              </button>
              <button
                className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 py-4 px-1 border-b-2 font-medium text-sm"
              >
                Guide d'Utilisation
              </button>
            </nav>
          </div>

          <div className="p-6">
            <DeploymentGuide />
            <UsageGuide />
          </div>
        </div>
      </div>
    </div>
  );
}