import React from 'react';
import { ExpertProfile } from '../components/providers/ExpertProfile';
import { experts } from '../data/experts';

export function ExpertsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Nos Experts</h1>
          <p className="text-xl text-gray-600">
            Une équipe de professionnels qualifiés à votre service
          </p>
        </div>
        
        <div className="space-y-8">
          {experts.map(expert => (
            <ExpertProfile key={expert.id} expert={expert} />
          ))}
        </div>
      </div>
    </div>
  );
}