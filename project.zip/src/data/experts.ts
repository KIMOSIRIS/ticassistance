export const experts = [
  {
    id: 'kagambega-ivan',
    name: 'Kagambega Ivan Maria',
    title: 'Administrateur Serveur et Base de Données',
    phone: '+225 0708088953',
    email: 'ivan.kagambega@ticassistance.com',
    location: 'Abidjan, Côte d\'Ivoire',
    specialties: [
      'Administration Windows Server',
      'Administration SQL Server',
      'Gestion des bases de données',
      'Sécurité des systèmes',
      'Maintenance préventive',
      'Support technique',
    ],
    certifications: [
      'Microsoft Certified: Azure Administrator Associate',
      'Microsoft Certified: SQL Server Database Administrator',
      'CompTIA Server+',
      'ITIL Foundation',
    ],
    experience: [
      'Plus de 8 ans d\'expérience en administration système et base de données',
      'Gestion d\'infrastructures critiques pour des entreprises de premier plan',
      'Expert en optimisation des performances des serveurs et bases de données',
      'Spécialiste en sécurité des données et conformité',
    ],
  },
];