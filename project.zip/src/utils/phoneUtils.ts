import { parsePhoneNumberFromString, isValidPhoneNumber } from 'libphonenumber-js';

export const formatPhoneNumber = (phoneNumber: string, countryCode = 'FR') => {
  const parsed = parsePhoneNumberFromString(phoneNumber, countryCode);
  return parsed ? parsed.formatInternational() : phoneNumber;
};

export const validatePhoneNumber = (phoneNumber: string, countryCode = 'FR') => {
  return isValidPhoneNumber(phoneNumber, countryCode);
};